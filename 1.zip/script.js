// let a = 20;
// alert(a);

// let b = 2007;
// alert(b);

// let nameJS = 'Брендан Эйх (Brendan Eich)'
// alert(nameJS);

// let c = 10;
// let d = 2;
// alert(c+d);
// alert(c-d);
// alert(c*d);
// alert(c/d);

// let e = 2;
// let power = e ** 5;
// alert(power);

// let f = 9;
// let g = 2;
// let result = f % g;
// alert(result);

// let num = 1;
// num += 5;
// num -= 3;
// num *= 7;
// num /= 3;
// num++;
// num--;
// alert(num);

// let age = Number(prompt('Сколько вам лет?'));
// alert(`Вам ${age} лет`);

// const user = {
//     name: 'kosha',
//     age: 3,
//     isAdmin: true
// };

// let name = String(prompt('Как Вас зовут?'));
// alert(`Привет, ${name}!`);
